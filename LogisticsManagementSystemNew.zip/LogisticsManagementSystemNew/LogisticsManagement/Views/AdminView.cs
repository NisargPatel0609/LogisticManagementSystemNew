﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticsManagement.Views
{
    public class AdminView
    {
        public static void Show()
        {
            Console.Clear();
            Console.WriteLine("----- ADMIN MENU -----");
            Console.WriteLine("1. Manage Customers");
            Console.WriteLine("2. Manage Warehouse Managers");
            Console.WriteLine("3. Manage Drivers");
            Console.WriteLine("4. Logout");
            Console.WriteLine("5. Exit");

            Console.Write("Enter your choice: ");
            string input = Console.ReadLine();
            if (int.TryParse(input, out int choice))
            {
                switch (choice)
                {
                    case 1:
                        ManageCustomers();
                        break;
                    case 2:
                        ManageManagers();
                        break;
                    case 3:
                        ManageDrivers();
                        break;
                    case 4:
                        new AuthenticationView().Show();
                        break;
                    case 5:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("Please enter valid option.");
                        Console.ResetColor();
                        Show();
                        break;
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Invalid input. Please enter a valid number.");
                Console.ResetColor();
                Show();
            }
        }
        public static void ViewUsers()
        {
            Console.WriteLine("list of users");
        }
        public static void DeleteUser()
        {
            Console.WriteLine("user deleted");
        }
        public static void ApproveUser()
        {
            Console.WriteLine("approved");
        }


        public static void ManageCustomers()
        {
            // Manage Customers submenu
            Console.WriteLine("----- MANAGE CUSTOMERS -----");
            Console.WriteLine("1. View All Customers");
            Console.WriteLine("2. Remove Customer");
            Console.WriteLine("3. Back to Admin Menu");
            Console.WriteLine("4. Logout");
            Console.WriteLine("5. Exit");

            Console.Write("Enter your choice: ");
            string input = Console.ReadLine();
            if (int.TryParse(input, out int choice))
            {
                switch (choice)
                {
                    case 1:
                        ViewCustomers();
                        break;
                    case 2:
                        DeleteCustomer();
                        break;
                    case 3:
                        Show();
                        break;
                    case 4:
                        new AuthenticationView().Show();
                        break;
                    case 5:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("Please enter valid option.");
                        Console.ResetColor();
                        Console.WriteLine();
                        Show();
                        break;
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Invalid input. Please enter a valid number.");
                Console.ResetColor();
                Console.WriteLine();
                ManageCustomers();
            }
        }
        public static void ViewCustomers()
        {
            ViewUsers();
            ManageCustomers();
        }
        public static void DeleteCustomer()
        {
            DeleteUser();
            ManageCustomers();
        }


        public static void ManageManagers()
        {
            // Manage Customers submenu
            Console.WriteLine("----- MANAGE WAREHOUSE MANAGER -----");
            Console.WriteLine("1. View All Managers");
            Console.WriteLine("2. Manager SignUp Approval");
            Console.WriteLine("3. Delete Manager");
            Console.WriteLine("4. Back to Admin Menu");
            Console.WriteLine("5. Logout");
            Console.WriteLine("6. Exit");

            Console.Write("Enter your choice: ");
            string input = Console.ReadLine();
            if (int.TryParse(input, out int choice))
            {
                switch (choice)
                {
                    case 1:
                        ViewManagers();
                        break;
                    case 2:
                        ApproveManager();
                        break;
                    case 3:
                        DeleteManager();
                        break;
                    case 4:
                        Show();
                        break;
                    case 5:
                        new AuthenticationView().Show();
                        break;
                    case 6:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("Please enter valid option.");
                        Console.ResetColor();
                        Console.WriteLine();
                        Show();
                        break;
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Invalid input. Please enter a valid number.");
                Console.ResetColor();
                Console.WriteLine();
                ManageManagers();
            }
        }
        public static void ViewManagers()
        {
            ViewUsers();
            ManageManagers();
        }
        public static void DeleteManager()
        {
            DeleteUser();
            ManageManagers();
        }
        public static void ApproveManager()
        {
            ApproveUser();
            ManageManagers();
        }


        public static void ManageDrivers()
        {
            Console.WriteLine("----- MANAGE DRIVERS -----");
            Console.WriteLine("1. View All Drivers");
            Console.WriteLine("2. Driver Signup Approval");
            Console.WriteLine("3. Delete Driver");
            Console.WriteLine("4. Back to Admin Menu");

            Console.Write("Enter your choice: ");
            string input = Console.ReadLine();
            if (int.TryParse(input, out int choice))
            {
                switch (choice)
                {
                    case 1:
                        ViewDrivers();
                        break;
                    case 2:
                        ApproveDriver();
                        break;
                    case 3:
                        DeleteDriver();
                        break;
                    case 4:
                        Show();
                        break;
                    case 5:
                        new AuthenticationView().Show();
                        break;
                    case 6:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("Please enter valid option.");
                        Console.ResetColor();
                        Console.WriteLine();
                        Show();
                        break;
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Invalid input. Please enter a valid number.");
                Console.ResetColor();
                Console.WriteLine();
                ManageDrivers();
            }
        }
        public static void ViewDrivers()
        {
            ViewUsers();
            ManageDrivers();
        }
        public static void DeleteDriver()
        {
            DeleteUser();
            ManageDrivers();
        }
        public static void ApproveDriver()
        {
            ApproveUser();
            ManageDrivers();
        }
    }
}
