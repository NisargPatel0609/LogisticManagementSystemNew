﻿using LogisticManagementSystem.Services.BusinessModels;
using LogisticManagementSystem.Services.Services.IServices;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.EntityFrameworkCore.Query.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticsManagement.Views
{
    public class ManagerView
    {
        private readonly IManagerService _managerService;

        public ManagerView() { }
        public ManagerView(IManagerService managerService)
        {
            _managerService = managerService;       
        }
        public void Show()
        {
            Console.Clear();
            Console.WriteLine("----- MANAGER MENU -----");
            Console.WriteLine("1. Manage Inventory");
            Console.WriteLine("2. Assign Driver to Order");
            Console.WriteLine("3. Update Order Status");
            Console.WriteLine("4. View Orders");
            Console.WriteLine("5. Logout");
            Console.WriteLine("6. Exit");

            Console.Write("Enter your choice: ");
            string input = Console.ReadLine();
            if (int.TryParse(input, out int choice))
            {
                switch (choice)
                {
                    case 1:
                        ManageInventory();
                        break;
                    case 2:
                        AssignDriverToOrder();
                        break;
                    case 3:
                        UpdateOrderStatus();
                        break;
                    case 4:
                        ViewOrders();
                        Show();
                        break;
                    case 5:
                        new AuthenticationView().Show();
                        break;
                    case 6:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("Please enter valid option.");
                        Console.ResetColor();
                        Console.WriteLine();
                        Show();
                        break;
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Invalid input. Please enter a valid number.");
                Console.ResetColor();
                Console.WriteLine();
                Show();
            }
        }


        public void ManageInventory()
        {
            Console.WriteLine("----- MANAGE INVENTORY -----");
            Console.WriteLine("1. View All Products");
            Console.WriteLine("2. Add New Product");
            Console.WriteLine("3. Update Product");
            Console.WriteLine("4. Remove Product");
            Console.WriteLine("5. Back to Manager Menu");
            Console.WriteLine("6. Logout");
            Console.WriteLine("7. Exit");

            Console.Write("Enter your choice: ");
            string input = Console.ReadLine();
            if (int.TryParse(input, out int choice))
            {
                switch (choice)
                {
                    case 1:
                        ViewProducts();
                        ManageInventory();
                        break;
                    case 2:
                        AddProduct();
                        ManageInventory();
                        break;
                    case 3:
                        UpdateProduct();
                        break;
                    case 4:
                        RemoveProduct();
                        break; 
                    case 5:
                        Show();
                        break;
                    case 6:
                        new AuthenticationView().Show();
                        break;
                    case 7:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("Please enter valid option.");
                        Console.ResetColor();
                        Console.WriteLine();
                        ManageInventory();
                        break;
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Invalid input. Please enter a valid number.");
                Console.ResetColor();
                Console.WriteLine();
                ManageInventory();
            }
        }

        public List<InventoryServiceModel> GetProducts()
        {
            List<InventoryServiceModel>? products = _managerService.GetProducts();
            return products;
        }
        public void ViewProducts()
        {
            try
            {
                List<InventoryServiceModel> products = GetProducts();
                if(products != null)
                {
                    Console.WriteLine("Id " + "ProductName " + "WarehouseId " + "ProductDescription " + "Price " + "IsActive ");
                    foreach (InventoryServiceModel product in products)
                    {
                        Console.WriteLine(product.Id + " " + product.ProductName + " " + product.WarehouseId + " " + product.ProductDescription + " " + product.Price + " " + product.IsActive);
                    }
                }
                else
                {
                    Console.WriteLine("No Products Available at moment.");
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        public void AddProduct()
        {
            Console.WriteLine("Enter Product Details...");

            Console.Write("Enter Product Name: ");
            string ProductName = Console.ReadLine();
            if (!Validation.ValidateName(ProductName)) AddProduct();

            Console.Write("Enter Product Quantity : ");
            string quantity = Console.ReadLine();
            int ProductQuantity = Validation.ValidateNumeric(quantity);
            if (ProductQuantity <= 0) AddProduct(); 
            
            Console.Write("Enter Product Description : ");
            string ProductDesctiption= Console.ReadLine();
            if (!Validation.ValidateString(ProductDesctiption)) AddProduct();

            Console.Write("Enter Price of Product : ");
            string price = Console.ReadLine();
            int ProductPrice = Validation.ValidateNumeric(price);
            if (ProductPrice <= 0)
            {
                Console.WriteLine("Invalid Price. Enter Valid Price.");
                AddProduct();
            };

            InventoryServiceModel product = new InventoryServiceModel()
            {
                ProductName = ProductName,
                Price = ProductPrice,
                ProductDescription = ProductDesctiption,
                ProductQuantity = ProductQuantity,
                IsActive = true,
                WarehouseId = 1
            };

            try
            {
                int result = _managerService.AddProduct(product);
                if(result > 0)
                {
                    Console.WriteLine("Product Added Successfully.");
                }
                else
                {
                    Console.WriteLine("Failed to Add Product.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Occurred while adding product.");
                Console.WriteLine(ex);
            }
        }
        public void UpdateProduct()
        {
            Console.WriteLine("List of Products.");
            ViewProducts();
            List<InventoryServiceModel>? products = GetProducts();

            Console.WriteLine("Enter Product Id for Update Product.");
            string input = Console.ReadLine();
            int productId = Validation.ValidateNumeric(input);
            if(productId<0) UpdateProduct();

            try
            {
                InventoryServiceModel product = _managerService.GetProduct(productId);
                if(product != null)
                {
                    EnterName:
                    Console.Write("Enter product name to update :");
                    string productName = Console.ReadLine();
                    if(Validation.ValidateString(productName))
                    {
                        product.ProductName = productName;
                        int res = _managerService.UpdateProduct(product);
                        if(res > 0)
                        {
                            Console.WriteLine("product updated successfully.");
                            ManageInventory();
                        }
                        else
                        {
                            Console.WriteLine("updation failed.");
                            ManageInventory();
                        }
                    }
                    else
                    {
                        Console.WriteLine("enter valid product name.");
                        goto EnterName;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid Product Id.");
                    UpdateProduct();
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
            }
            ManageInventory();
        }
        public void RemoveProduct()
        {
            Console.WriteLine("List of Products.");
            ViewProducts();
            List<InventoryServiceModel>? products = GetProducts();

            Console.WriteLine("Enter Product Id to delete Product.");
            string input = Console.ReadLine();
            int productId = Validation.ValidateNumeric(input);
            if (productId < 0) UpdateProduct();

            try
            {
                InventoryServiceModel product = _managerService.GetProduct(productId);
                if (product != null)
                {
                    int res = _managerService.DeleteProduct(product);
                    if (res > 0)
                    {
                        Console.WriteLine("product deleted successfully.");
                        ManageInventory();
                    }
                    else
                    {
                        Console.WriteLine("updation failed.");
                        ManageInventory();
                    }
                }
                else
                {
                    Console.WriteLine("Invalid Product Id.");
                    RemoveProduct();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            ManageInventory();
        }
        public void AssignDriverToOrder()
        {
            ViewPendingOrders();
            ViewAvailableDrivers();

            Console.Write("Enter order id : ");
            string oId = Console.ReadLine();
            int orderId = Validation.ValidateNumeric(oId);
            if(orderId < 0) AssignDriverToOrder();

            Console.Write("Enter resource id : ");
            string resId = Console.ReadLine();
            int resourceId = Validation.ValidateNumeric(resId);
            if (resourceId < 0) AssignDriverToOrder();

            OrderDetailsServiceModel orderDetails = GetOrderDetails(orderId);
            ResourceServiceModel resource = GetResource(resourceId);
            if (orderDetails != null && resource != null)
            {
                Console.WriteLine("Enter Choice ..");
                Console.WriteLine("1. Confirm");
                Console.WriteLine("2. Back to Menu");
                Console.Write("Enter your choice: ");
                string input = Console.ReadLine();
                if (int.TryParse(input, out int choice))
                {
                    switch (choice)
                    {
                        case 1:
                            AssignOrder(orderDetails,resource);
                            break;
                        case 2:
                            Show();
                            break;
                        default:
                            Console.ForegroundColor = ConsoleColor.DarkRed;
                            Console.WriteLine("Please enter valid option.");
                            Console.ResetColor();
                            Console.WriteLine();
                            AssignDriverToOrder();
                            break;
                    }
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("Invalid input. Please enter a valid number.");
                    Console.ResetColor();
                    Console.WriteLine();
                    AssignDriverToOrder();
                }
            }
            else
            {

            }
        }
        public void ViewPendingOrders()
        {
            try
            {
                List<OrderDetailsServiceModel>? pendingOrders = _managerService.GetOrdersDetails("Pending");
                if(pendingOrders != null)
                {
                    Console.WriteLine("List of Pending Orders");
                    Console.WriteLine("order id " +" inventory id " + " quantity " + "Total amount " + "status");
                    foreach (OrderDetailsServiceModel pendingOrder in pendingOrders)
                    {
                        Console.WriteLine(pendingOrder.OrderId + " " + pendingOrder.InventoryId + " " + pendingOrder.Quantity + " " + pendingOrder.TotalAmount + " " + pendingOrder.OrderStatus);
                    }
                }
                else
                {
                    Console.WriteLine("No Pengin Orders.");
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        public void ViewAvailableDrivers()
        {
            try
            {
                List<ResourceServiceModel>? availableResources = _managerService.GetAvailableResources();
                if (availableResources != null)
                {
                    Console.WriteLine("List of Available Drivers.");
                    Console.WriteLine("Resource Id "+" isAvailable");
                    foreach (ResourceServiceModel availableResource in availableResources)
                    {
                        Console.WriteLine(availableResource.ResourceId + " " + availableResource.IsAvailable);
                    }
                }
                else
                {
                    Console.WriteLine("No Available Resources.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        public OrderDetailsServiceModel GetOrderDetails(int id, string? query=null)
        {
            try
            {
                return _managerService.GetOrderDetails(id,query);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }
        }
        public ResourceServiceModel GetResource(int id, bool? query=null)
        {
            try
            {
                return _managerService.GetResource(id,query);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }
        }

        public void AssignOrder(OrderDetailsServiceModel orderDetails, ResourceServiceModel resource)
        {
            try
            {
                orderDetails.OrderStatus = "Dispatched";
                resource.IsAvailable = false;
                int result = _managerService.AssignOrderToDriver(orderDetails, resource);
                if(result > 0)
                {
                    Console.WriteLine("Assignment Successfull.");
                    Show();
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
            }
            Show();
        }
        public void UpdateOrderStatus()
        {
            List<OrderDetailsServiceModel> orders = ViewOrders();
            Console.WriteLine("Enter order id to update order status");
            string input  = Console.ReadLine();
            int orderId = Validation.ValidateNumeric(input);
            if (orderId < 0) Show();

            OrderDetailsServiceModel order = _managerService.GetOrderDetails(orderId);
            if(order != null)
            {
                order.OrderStatus = "Delievered";
                int result = _managerService.UpdateOrderDetails(order);
                if(result > 0)
                {
                    Console.WriteLine("updated successfully.");
                    Show();
                }
                else
                {
                    Console.WriteLine("Updation failed.");
                    Show();
                }
            }
            else
            {
                Console.WriteLine("Invalid Order Id.");
                Show();
            }
        }
        public List<OrderDetailsServiceModel> ViewOrders()
        {
            try
            {
                List<OrderDetailsServiceModel> ordersDetails = _managerService.GetOrdersDetails();
                Console.WriteLine("list of orders");
                foreach (OrderDetailsServiceModel orderDetail in ordersDetails)
                {
                    Console.WriteLine(orderDetail.OrderId + " " + orderDetail.OrderStatus +" " + orderDetail.Quantity +" " + orderDetail.TotalAmount);
                }
                return ordersDetails;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }
        }

    }
}
