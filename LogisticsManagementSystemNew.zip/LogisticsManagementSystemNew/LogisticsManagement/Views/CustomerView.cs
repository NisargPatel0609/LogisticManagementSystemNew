﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticsManagement.Views
{
    public class CustomerView
    {
        public static void Show()
        {
            Console.Clear();
            Console.WriteLine("----- CUSTOMER MENU -----");
            Console.WriteLine("1. View Products");
            Console.WriteLine("2. View Orders");
            Console.WriteLine("3. Logout");
            Console.WriteLine("4. Exit");

            Console.Write("Enter your choice: ");
            string input = Console.ReadLine();
            if (int.TryParse(input, out int choice))
            {
                switch (choice)
                {
                    case 1:
                        ViewProducts();
                        break;
                    case 2:
                        ViewOrders();
                        break;
                    case 4:
                        new AuthenticationView().Show();
                        break;
                    case 5:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("Please enter valid option.");
                        Console.ResetColor();
                        Console.WriteLine();
                        Show();
                        break;
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Invalid input. Please enter a valid number.");
                Console.ResetColor();
                Console.WriteLine();
                Show();
            }
        }


        public static void ViewProducts()
        {
            Console.WriteLine("List of products");
            Console.WriteLine("1. View Product Details ");
            Console.WriteLine("2. Back to Main Menu ");
            Console.WriteLine("3. Logout ");
            Console.WriteLine("4. Exit");

            Console.WriteLine("Enter your choice: ");
            string input = Console.ReadLine();
            if (int.TryParse(input, out int choice))
            {
                switch (choice)
                {
                    case 1:
                        ViewProductDetails();
                        break;
                    case 2:
                        Show();
                        break;
                    case 3:
                        new AuthenticationView().Show();
                        break;
                    case 4:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("Please enter valid option.");
                        Console.ResetColor();
                        Console.WriteLine();
                        ViewProducts();
                        break;
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Invalid input. Please enter a valid number.");
                Console.ResetColor();
                ViewProducts();
            }
        }

        public static void ViewProductDetails()
        {
            Console.WriteLine("----- PRODUCT DETAILS -----");
            Console.WriteLine($"Name:");
            Console.WriteLine($"Price:");
            Console.WriteLine($"Description:");


            Console.WriteLine("1. Buy Product");
            Console.WriteLine("2. Back to Browse Products");
            Console.WriteLine("3. Back to Customer Menu");
            Console.WriteLine("Enter your choice: ");
            string input = Console.ReadLine();
            if (int.TryParse(input, out int choice))
            {
                switch (choice)
                {
                    case 1:
                        PurchaseProduct();
                        break;
                    case 2:
                        ViewProducts();
                        break;
                    case 3:
                        Show();
                        break;
                    case 4:
                        new AuthenticationView().Show();
                        break;
                    case 5:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("Please enter valid option.");
                        Console.ResetColor();
                        Console.WriteLine();
                        ViewProductDetails();
                        break;
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Invalid input. Please enter a valid number.");
                Console.ResetColor();
                Console.WriteLine();
                ViewProductDetails();
            }
        }

        public static void PurchaseProduct()
        {
            Console.WriteLine("purchase made");
            ViewProductDetails();
        }
        public static void ViewOrders()
        {
            Console.WriteLine("list of orders");
            Show();
        }
    }
}
