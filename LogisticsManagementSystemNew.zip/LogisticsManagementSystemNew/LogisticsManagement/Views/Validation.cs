﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace LogisticsManagement.Views
{
    public class Validation
    {
        public static bool ValidateName(string name)
        {
            if (!string.IsNullOrWhiteSpace(name) && char.IsLetter(name[0]) && name.Length > 3)
            {
                return true;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Invalid Name.");
                Console.ResetColor();
                Console.WriteLine();
                return false;
            }
        }
        public static bool ValidateEmail(string email) 
        {
            string emailPattern = @"^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$";
            if (!string.IsNullOrWhiteSpace(email) && Regex.IsMatch(email, emailPattern))
            {
                return true;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Invalid Email.");
                Console.ResetColor();
                Console.WriteLine();
                return false;
            }
        }

        public static bool ValidatePhone(string phoneNumber)
        {
            if (!string.IsNullOrWhiteSpace(phoneNumber) && phoneNumber.Length == 10 && long.TryParse(phoneNumber, out _))
            {
                return true;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Invalid Phone Number.");
                Console.ResetColor();
                Console.WriteLine();
                return false;
            }
        }
        public static bool ValidatePassword(string password)
        {
            string passwordPattern = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@#$%^&+=!]).{5,}$";
            if (!string.IsNullOrWhiteSpace(password) && Regex.IsMatch(password, passwordPattern))
            {
                return true;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Invalid Password.");
                Console.ResetColor();
                Console.WriteLine();
                return false;
            }
        }
        public static bool ValidateConfirmpassword(string password, string confirmPassword)
        {
            if(!string.IsNullOrWhiteSpace(password) && password == confirmPassword)
            {
                return true;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Password and confirm password does not match.");
                Console.ResetColor();
                Console.WriteLine();
                return false;
            }
        }

        public static int ValidateNumeric(string  number)
        {
            if(!string.IsNullOrWhiteSpace(number) && int.TryParse(number, out int value)){
                return value;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Invalid Input.");
                Console.ResetColor();
                Console.WriteLine();
                return -1;
            }
        }
        public static bool ValidateString(string name)
        {
            if (!string.IsNullOrWhiteSpace(name) && char.IsLetter(name[0]) && name.Length > 3)
            {
                return true;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Invalid Name.");
                Console.ResetColor();
                Console.WriteLine();
                return false;
            }
        }
    }
}
