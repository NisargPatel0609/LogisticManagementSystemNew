﻿using LogisticManagementSystem.DataAccess.Models;
using LogisticManagementSystem.DataAccess.Repository;
using LogisticManagementSystem.DataAccess.Repository.IRepository;
using LogisticManagementSystem.Services.Services;
using LogisticManagementSystem.Services.Services.IServices;
using LogisticsManagement.Views;
using Microsoft.Extensions.DependencyInjection;

namespace LogisticsManagement
{
    internal class Program
    {
        static void Main(string[] args)
        {
            IServiceProvider provider = new ServiceCollection()
                .AddDbContext<LogisticManagementContext>()
                .AddScoped<IAuthenticationRepository,AuthenticationRepository>()
                .AddScoped<IAuthenticationService,AuthenticationService>()
                .AddScoped<IManagerService,ManagerService>()
                .AddScoped<IManagerRepository,ManagerRepository>()
                .BuildServiceProvider();

            Console.WriteLine("---- Welcome to Logistics Management System -----");

            var authService = provider.GetService<IAuthenticationService>();
            var managerService = provider.GetService<IManagerService>();

            AuthenticationView auth = new AuthenticationView(authService,managerService);

            auth.Show();

        }
    }
}
