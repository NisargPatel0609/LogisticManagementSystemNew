﻿using LogisticManagementSystem.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticManagementSystem.DataAccess.Repository.IRepository
{
    public interface IManagerRepository
    {
        public Inventory GetProduct(int productId);

        public List<Inventory>? GetProducts();

        public int AddProduct(Inventory product);

        public int UpdateProduct(Inventory product);

        public int DeleteProduct(Inventory inventory);

        public List<OrderDetail> GetOrdersDetails(string? query = null);

        public List<Resource> GetAvailableResources();

        public Resource? GetResource(int id, bool? query = null);
        
        public OrderDetail GetOrderDetails(int id, string? query = null);

        public int AssignOrderToResource(OrderDetail orderDetail, Resource resource);

        public int UpdateOrderDetails(OrderDetail order);
    }
}
