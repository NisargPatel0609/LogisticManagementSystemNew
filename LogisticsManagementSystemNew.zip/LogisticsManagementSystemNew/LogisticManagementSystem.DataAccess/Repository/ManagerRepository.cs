﻿using LogisticManagementSystem.DataAccess.Models;
using LogisticManagementSystem.DataAccess.Repository.IRepository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticManagementSystem.DataAccess.Repository
{
    public class ManagerRepository : IManagerRepository
    {
        private readonly LogisticManagementContext _db;
        public ManagerRepository(LogisticManagementContext db)
        {
            _db = db;
        }

        public int AddProduct(Inventory product)
        {
            try
            {
                _db.Inventories.Add(product);
                return _db.SaveChanges();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
                return -1;
            }
        }

        public List<Inventory>? GetProducts()
        {
            try
            {
                List<Inventory> products = _db.Inventories.ToList();
                return products;
            }
            catch(Exception ex)
            {
                return null;
            }
        }

        public Inventory? GetProduct(int id)
        {
            try
            {
                return _db.Inventories.FirstOrDefault(x => x.Id == id);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }
        }

        public int UpdateProduct(Inventory product)
        {
            try
            {
                Inventory? inventory = _db.Inventories.FirstOrDefault(p=>p.Id == product.Id);
                if (inventory != null)
                {
                    inventory.ProductName = product.ProductName;
                    _db.Inventories.Update(inventory);
                    return _db.SaveChanges();
                }
                else
                {
                    return -1;
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
                return -1;
            }
        }

        public int DeleteProduct(Inventory product)
        {
            try
            {
                Inventory? inventory = _db.Inventories.FirstOrDefault(p => p.Id == product.Id);
                if (inventory != null)
                {
                    inventory.ProductName = product.ProductName;
                    _db.Inventories.Remove(inventory);
                    return _db.SaveChanges();
                }
                else
                {
                    return -1;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return -1;
            }
        }

        public List<OrderDetail> GetOrdersDetails(string? query = null)
        {
            try
            {
                if (query == null)
                {
                    return _db.OrderDetails.ToList();
                }
                else
                {
                    return _db.OrderDetails.Where(order => order.OrderStatus == query).ToList();
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }
        }

        public List<Resource> GetAvailableResources()
        {
            try
            {
                return _db.Resources.Where(res => res.IsAvailable == true).ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }
        }

        public Resource? GetResource(int id, bool? query = null)
        {
            try
            {
                if(query == null) 
                { 
                    return _db.Resources.FirstOrDefault(res => res.Id == id);
                }
                else
                {
                    return _db.Resources.FirstOrDefault(res => (res.Id == id ) && (res.IsAvailable == query));
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }
        }

        public OrderDetail GetOrderDetails(int id, string? query = null)
        {
            try
            {
                if (query == null)
                {
                    return _db.OrderDetails.FirstOrDefault(order => order.Id == id);
                }
                else
                {
                    return _db.OrderDetails.FirstOrDefault(order => (order.Id == id) && (order.OrderStatus == query));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }
        }

        public int AssignOrderToResource(OrderDetail orderDetail, Resource resource)
        {
            try
            {
                OrderDetail od = _db.OrderDetails.FirstOrDefault(order => order.Id == orderDetail.Id);
                od.OrderStatus = orderDetail.OrderStatus;
                _db.OrderDetails.Update(od);

                Resource res = _db.Resources.FirstOrDefault(r => r.Id == orderDetail.Id);
                res.IsAvailable = resource.IsAvailable;
                _db.Resources.Update(res);

                ResourceMapping resourceMapping = new ResourceMapping()
                {
                    ManagerId = 1,
                    OrderDetailsId = orderDetail.Id,
                    ResourceId = resource.Id
                };

                _db.ResourceMappings.Add(resourceMapping);
                return _db.SaveChanges();
            }
            catch( Exception ex )
            {
                Console.WriteLine(ex);
                return -1;
            }
        }

        public int UpdateOrderDetails(OrderDetail order)
        {
            try
            {
                OrderDetail od = _db.OrderDetails.FirstOrDefault(o => o.Id == order.Id);
                od.OrderStatus = order.OrderStatus;
                _db.OrderDetails.Update(od);
                return _db.SaveChanges();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
                return -1;
            }
        }
    }
}
