﻿using LogisticManagementSystem.DataAccess.Models;
using LogisticManagementSystem.DataAccess.Repository.IRepository;
using LogisticManagementSystem.Services.BusinessModels;
using LogisticManagementSystem.Services.Services.IServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticManagementSystem.Services.Services
{
    public class ManagerService : IManagerService
    {
        private readonly IManagerRepository _managerRepo;
        public ManagerService(IManagerRepository managerRepository)
        {
            _managerRepo = managerRepository;
        }

        private Inventory ConverInventoryServiceModelToInventory(InventoryServiceModel product)
        {
            Inventory inventory = new Inventory()
            {
                Id = product.Id,
                ProductName = product.ProductName,
                Price = product.Price,
                ProductDescription = product.ProductDescription,
                IsActive = product.IsActive,
                ProductQuantity = product.ProductQuantity,
                WarehouseId = product.WarehouseId
            };
            return inventory;
        }
        private ResourceServiceModel ConvertResourceToResourceServiceModel(Resource resource)
        {
            ResourceServiceModel resourceServiceModel = new ResourceServiceModel()
            {
                IsAvailable = resource.IsAvailable,
                ResourceId = resource.Id
            };
            return resourceServiceModel;
        }
        private Resource ConvertResourceServiceModelToResource(ResourceServiceModel resource)
        {
            Resource res = new Resource()
            {
                IsAvailable = resource.IsAvailable,
                ResourceId = resource.ResourceId
            };
            return res;
        }
        private OrderDetailsServiceModel ConvertOrderDetailToOrderDetailServiceModel(OrderDetail od)
        {
            OrderDetailsServiceModel orderDetails = new OrderDetailsServiceModel()
            {
                InventoryId = od.InventoryId,
                OrderId = od.OrderId,
                OrderStatus = od.OrderStatus,
                Quantity = od.Quantity,
                TotalAmount = od.TotalAmount
            };
            return orderDetails;
        }
        private OrderDetail ConvertOrderDetailServiceModelToOrderDetails(OrderDetailsServiceModel od)
        {
            OrderDetail orderDetails = new OrderDetail()
            {
                InventoryId = od.InventoryId,
                OrderId = od.OrderId,
                OrderStatus = od.OrderStatus,
                Quantity = od.Quantity,
                TotalAmount = od.TotalAmount
            };
            return orderDetails;
        }
        private InventoryServiceModel ConverInventoryToInventoryServiceModel(Inventory inventory)
        {
            InventoryServiceModel product = new InventoryServiceModel()
            {
                Id = inventory.Id,
                ProductName = inventory.ProductName,
                Price = inventory.Price,
                ProductDescription = inventory.ProductDescription,
                IsActive = inventory.IsActive,
                ProductQuantity = inventory.ProductQuantity,
                WarehouseId = inventory.WarehouseId
            };
            return product;
        }

        public int AddProduct(InventoryServiceModel product)
        {
            Inventory inventory = ConverInventoryServiceModelToInventory(product);
            try
            {
                return _managerRepo.AddProduct(inventory);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return -1;
            }
        }

        public List<InventoryServiceModel>? GetProducts()
        {
            try
            {
                List<Inventory> inventories = _managerRepo.GetProducts();
                List<InventoryServiceModel> products = new List<InventoryServiceModel>();

                foreach (Inventory inventory in inventories)
                {
                    products.Add(new InventoryServiceModel()
                    {
                        Id = inventory.Id,
                        IsActive = inventory.IsActive,
                        Price = inventory.Price,
                        ProductDescription = inventory.ProductDescription,
                        ProductName = inventory.ProductName,
                        ProductQuantity = inventory.ProductQuantity,
                        WarehouseId = inventory.WarehouseId
                    });
                }
                return products;
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }
        }

        public InventoryServiceModel GetProduct(int productId)
        {
            try
            {
                Inventory inventory =  _managerRepo.GetProduct(productId);
                InventoryServiceModel product = ConverInventoryToInventoryServiceModel(inventory);
                return product;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public int UpdateProduct(InventoryServiceModel product)
        {
            try
            {
                Inventory inventory = ConverInventoryServiceModelToInventory(product);
                return _managerRepo.UpdateProduct(inventory);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return -1;
            }
        }

        public int DeleteProduct(InventoryServiceModel product)
        {
            try
            {
                Inventory inventory = ConverInventoryServiceModelToInventory(product);
                return _managerRepo.DeleteProduct(inventory);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return -1;
            }
        }

        public List<OrderDetailsServiceModel>? GetOrdersDetails(string? query = null)
        {
            try
            {
                List<OrderDetail> orderList = _managerRepo.GetOrdersDetails(query);
                List<OrderDetailsServiceModel> orders = new List<OrderDetailsServiceModel>();

                foreach (OrderDetail orderDetail in orderList)
                {
                    orders.Add(new OrderDetailsServiceModel()
                    {
                        InventoryId = orderDetail.InventoryId,
                        Quantity = orderDetail.Quantity,
                        OrderStatus = orderDetail.OrderStatus,
                        TotalAmount = orderDetail.TotalAmount,
                        OrderId = orderDetail.OrderId
                    });
                }
                return orders;
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }
        }

        public List<ResourceServiceModel>? GetAvailableResources()
        {
            try
            {
                List<Resource> resourcerList = _managerRepo.GetAvailableResources();
                List<ResourceServiceModel> resources = new List<ResourceServiceModel>();

                foreach (Resource resource in resourcerList)
                {
                    resources.Add(new ResourceServiceModel()
                    {
                        IsAvailable = resource.IsAvailable,
                        ResourceId = resource.ResourceId
                    });
                }
                return resources;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }
        }

        public ResourceServiceModel GetResource(int resourceId, bool? query = null)
        {
            try
            {
                Resource res = _managerRepo.GetResource(resourceId,query);
                return ConvertResourceToResourceServiceModel(res);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }
        }

        public OrderDetailsServiceModel GetOrderDetails(int orderId, string? query = null)
        {
            try
            {
                OrderDetail od = _managerRepo.GetOrderDetails(orderId, query);
                return ConvertOrderDetailToOrderDetailServiceModel(od);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }
        }

        public int AssignOrderToDriver(OrderDetailsServiceModel orderDetails, ResourceServiceModel resource)
        {
            try
            {
                OrderDetail order = ConvertOrderDetailServiceModelToOrderDetails(orderDetails);
                Resource res = ConvertResourceServiceModelToResource(resource);
                return _managerRepo.AssignOrderToResource(order, res);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
                return -1;
            }
        }

        public int UpdateOrderDetails(OrderDetailsServiceModel orderDetails)
        {
            try
            {
                OrderDetail order = ConvertOrderDetailServiceModelToOrderDetails(orderDetails);
                return _managerRepo.UpdateOrderDetails(order);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return -1;
            }
        }
    }
}
