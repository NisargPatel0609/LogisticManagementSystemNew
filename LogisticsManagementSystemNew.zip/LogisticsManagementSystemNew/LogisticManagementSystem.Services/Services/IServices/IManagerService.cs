﻿using LogisticManagementSystem.DataAccess.Models;
using LogisticManagementSystem.Services.BusinessModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticManagementSystem.Services.Services.IServices
{
    public interface IManagerService
    {
        List<InventoryServiceModel>? GetProducts();

        public int AddProduct(InventoryServiceModel product);

        public InventoryServiceModel GetProduct(int productId);

        public int UpdateProduct(InventoryServiceModel product);

        public int DeleteProduct(InventoryServiceModel product);

        public List<OrderDetailsServiceModel>? GetOrdersDetails(string? query = null);

        public List<ResourceServiceModel>? GetAvailableResources();

        public ResourceServiceModel GetResource(int resourceId, bool? query = null);

        public OrderDetailsServiceModel GetOrderDetails(int orderId, string? query = null);

        public int AssignOrderToDriver(OrderDetailsServiceModel orderDetails, ResourceServiceModel resource);

        public int UpdateOrderDetails(OrderDetailsServiceModel orderDetails);
    }
}
