﻿using LogisticManagementSystem.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticManagementSystem.Services.BusinessModels
{
    public class OrderDetailsServiceModel
    {
        public int OrderId { get; set; }
        public int InventoryId { get; set; }

        public int Quantity { get; set; }

        public decimal TotalAmount { get; set; }

        public string OrderStatus { get; set; } = null!;
    }
}
